<?php

$db_name = 'mysql:host=localhost;dbname=food_db';
$user_name = 'root';
$user_password = '';

$conn = new mysqli("localhost", $user_name, $user_password, "food_db");

?>